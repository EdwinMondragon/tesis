**UNIVERSIDAD NACIONAL**

**TORIBIO RODRÍGUEZ DE MENDOZA DE AMAZONAS**

 ****![null|null](img_0.png)​

**FACULTAD DE INGENIERÍA Y CIENCIAS AGRARIAS** 

**ESCUELA PROFESIONAL DE INGENIERÍA AGRÓNOMA**

**PROYECTO DE TESIS PARA OBTENER EL GRADO DE INGENIERO AGRÓNOMO** 

**AISLADOS NATIVOS DE *Metarhizium* spp *.* CON POTENCIAL DE BIOCONTROL SOBRE EL PICUDO RAYADO DEL PLÁTANO (*Metamasius hemipterus*) EN ÑUNYA JALCA, AMAZONAS**

**Autor: Edwin Mondragon Herrera**

**Asesor: Mg. Angel Fernando Huamán Pilco**

									**Registro (.......)**

**CHACHAPOYAS – PERÚ**

**2025**

1. **Título**

Aislados nativos de *Metarhizium spp*. con potencial de biocontrol sobre el picudo rayado del plátano (*Metamasius hemipterus*) en Ñunya Jalca, Amazonas

1. **Problema** **de investigación**

¿Cuáles son los aislados nativos de *Metarhizium spp*. con potencial de biocontrol sobre el picudo rayado del plátano (*Metamasius hemipterus*) en Ñunya Jalca, Amazonas?

1. **Objetivos**
    1.  **Objetivo general**

Caracterizar y seleccionar aislados nativos de *Metarhizium spp*. con potencial de biocontrol sobre el picudo rayado del plátano (*Metamasius hemipterus*) en Ñunya Jalca, Amazonas

    1.  **Objetivos específicos** 
* _~~​*​**Aislar y caracterizar morfológicamente aislados nativos de *Metarhizium spp* de acuerdo a sus carac**​*​~~ _*terísticas macroscópicas y microscópicas _~~​* **.** *​~~ _*
* _~~​*​**Caracterizar fisiológicamente los aislados nativos de *Metarhizium spp*​**​*~~, mediante variables: crecimiento micelial (MC); producción de conidias (PdC); germinación de conidios  ****(GdC)._
* _~~​*​**Evaluar la patogenicidad de los aislados nativos de *Metarhizium spp *. sobre adultos sanos de *Metamasius hemipterus * .**​*​*​**​*​~~_
* _~~​*​**Evaluar la producción de conidios de los aislados nativos de *Metarhizium spp *. en arroz como sustrato*​*​*** para posible producción masiva _~~​* ** .***​~~ _~~_
1. **Antecedentes**

El género *Metarhizium* comprende hongos entomopatógenos con amplia distribución geográfica y destacado potencial como agentes de control biológico, debido a su especificidad hacia determinados hospedadores, bajo impacto ambiental y facilidad de producción a nivel industrial. Algunas especies muestran un comportamiento generalista, como *M*. *anisopliae*, capaz de infectar insectos de diversos órdenes, mientras que otras, como *M*. *acridum*, presentan alta especificidad. Esta variabilidad en la especificidad del hospedador ha impulsado investigaciones orientadas a comprender sus mecanismos de infección, la expresión de genes relacionados con la virulencia, y la producción de enzimas y toxinas que facilitan la invasión del hospedador (Aw & Hue, 2017).

Baró *et al*. (2022) en su estudio, caracterizaron seis aislados fúngicos del género *Metarhizium* provenientes de insectos y suelos en Cuba, con el objetivo de identificar su potencial como agentes de control biológico contra *Cylas formicarius*, plaga de la papa. Los aislados se cultivaron en medios específicos y se evaluaron mediante análisis morfológico, cultural y molecular utilizando los genes ef1a, rpb1, rpb2 y 5TEF. Se identificaron cinco aislados como *M*. *anisopliae* sensu stricto y uno como *M*. *robertsii*. También evaluaron el crecimiento micelial y la esporulación en distintos medios, destacando LBM-267 y LBM-11 por su alto rendimiento. Para pruebas de patogenicidad se aplicaron cinco concentraciones de conidios sobre adultos de *C*. *formicarius*, registrándose la mortalidad durante 21 días. Los análisis estadísticos confirmaron diferencias significativas entre tratamientos. Concluyendo, LBM-267 representó ser un candidato prometedor para el desarrollo de bioinsecticidas en programas de manejo integrado de plagas.

En su trabajo de investigación Mayo (2024), aisló cinco cepas nativas de *Metarhizium sp*. con el objetivo de identificar y seleccionar aislamientos con potencial de biocontrol contra la chinche negra del cacao (*Antiteuchus tripterus*) en Tabasco, México. Realizó la caracterización morfológica, molecular, fisiológica y patogénica de los aislamientos. Además, se estudió el crecimiento micelial, la germinación y la producción de conidios en medio SDA a temperaturas de 25, 30 y 35 °C. Mediante análisis molecular, los aislamientos fueron identificados como *Metarhizium brunneum*. En este estudio se encontraron diferencias significativas (P < 0.0085) en el crecimiento micelial a 25 °C, determinando que el intervalo de temperatura idónea para los aislamientos era de 25 a 30 °C. En cuanto a la germinación de conidios al 50% (TG50) varió entre 7.8 y 21.9 horas, y para TG90 varió entre 9.5 y 27.7 horas. Los cinco aislamientos evaluados demostraron efectividad patogénica contra *A*. *tripterus*, con tasas de mortalidad que oscilaron entre el 72 % y el 96 %.

Valle *et al*. (2021), en su investigación evaluaron veinte aislamientos monospóricos nativos de *Metarhizium spp*. aislados de suelos e insectos micosados en cultivos de caña de azúcar en Pastaza, Ecuador, con el objetivo de determinar su potencial biocontrol contra *Mahanarva andigena* (salivazo). El ensayo, diseñado completamente al azar con seis repeticiones por aislamiento, permitió identificar variabilidad significativa en parámetros como crecimiento radial, tasa de crecimiento y producción de conidios. El aislamiento DAS5401 presentó el mayor crecimiento micelial (64,7 mm) y una tasa de expansión diaria de 2,99 mm/día, destacando también en producción conidial junto a otros aislamientos como TS6302 y SJS5101, con concentraciones superiores a 1 x 10^8^ conidios/mL. Estos resultados evidencian la diversidad funcional entre cepas locales de *Metarhizium spp*. y su potencial como candidatos para formulaciones micoinsecticidas destinadas al manejo del salivazo en condiciones de laboratorio, invernadero y campo.

Algarate & Marianella (2023), evaluaron la eficacia del hongo entomopatógeno *Metarhizium anisopliae* en el control de adultos de *Cryptocephalus sp*. bajo condiciones de laboratorio. Para ello, se emplearon cuatro concentraciones del inóculo (10^5^, 10^6^, 10^7^ y 10^8^ esporas/mL), aplicadas en tratamientos con cinco repeticiones cada uno, utilizando 10 adultos por repetición. La mortalidad fue registrada diariamente durante un periodo de siete días posteriores a la inoculación, y se confirmó la infección mediante la técnica de cámara húmeda. Los resultados indicaron un aumento progresivo en la mortalidad con el incremento de la concentración del hongo, obteniéndose valores del 40 %, 56 %, 92 % y 100 % para las concentraciones de 10^5^, 10^6^, 10^7^ y 10^8^ esporas/mL, respectivamente. El análisis estadístico reveló que los tratamientos correspondientes a las concentraciones de 10⁶ y 10⁷, así como 10⁷ y 10⁸, no presentaron diferencias significativas entre sí, aunque sí mostraron diferencias con respecto al tratamiento control. Estos hallazgos evidencian el alto potencial de esta cepa de *M*. *anisopliae* para el control biológico de adultos de *Cryptocephalus sp*., destacándose como una alternativa prometedora en condiciones de laboratorio.

Chuquibala *et al*. (2023), evaluaron la actividad biológica in vitro de *Beauveria bassiana*, *Beauveria peruviensis* y *Metarhizium sp*. contra *Hypothenemus hampei*, mediante dos ensayos realizados en distintos momentos. Se estudiaron parámetros como la producción, viabilidad de conidios y la patogenicidad a tres concentraciones (1 x 10^5^, 1 x 10^7^ y 1 x 10^9^ conidios/mL). Además, se calcularon los tiempos letales (LT~50~ y LT~90~) y las concentraciones letales (LC~50~ y LC~90~) de cada aislamiento. Obtuvieron resultados con diferencias significativas en la producción (P < 0,001) y viabilidad de los conidios (P < 0,041), siendo *B*. *bassiana* el aislamiento con mayor producción de conidios y *B*. *peruviensis* el de mayor viabilidad. En cuanto a la patogenicidad, también se observaron diferencias entre tratamientos en ambos ensayos (ensayo 1: P < 0,0009; ensayo 2: P < 0,0001). Las mayores tasas de mortalidad sobre *H*. *hampei* se registraron en los tratamientos con *B*. *bassiana* (1 x 10^9^ y 1 x 10^7^ conidios/mL) y *B*. *peruviensis* (1 x 10^7^ conidios/mL). Asimismo, los valores más bajos de LT~50~ y LT~90~ correspondieron a estos mismos tratamientos, al igual que las concentraciones letales más eficaces (LC~50~ y LC~90~). Estos hallazgos sugieren que tanto *B*. *bassiana* como *B*. *peruviensis* presentan características in vitro prometedoras y podrían ser consideradas en evaluaciones de campo para determinar su eficacia real como agentes de biocontrol contra *H*. *hampei*.

En el estudio desarrollado por Oliva *et al*. (2024), se aislaron y caracterizaron dieciocho cepas nativas de *Metarhizium sp*. provenientes de muestras de suelo recolectadas en la provincia de Rodríguez de Mendoza, Perú, con el objetivo de evaluar su morfología, fisiología y capacidad patogénica. Las colonias presentaron una variación notable en la coloración, que incluyó tonalidades entre amarillo-gris, blanco, marrón y oliva, con bordes característicos de tipo ondulado. Respecto al crecimiento radial, los aislados LLM-M2 y TOR-M16 mostraron los mayores promedios, alcanzando 43,15 mm y 42,85 mm, respectivamente. En términos de producción de conidios a los 15 días, el aislamiento LLM-M2 destacó con una concentración de 9,8 x 10^7^ conidios/mL. Asimismo, el aislado TOR-M16 presentó una germinación del 100 % a las 14 horas de incubación, evidenciando su alta viabilidad. En cuanto al crecimiento micelial acumulado, el aislado CMR-M7 alcanzó el 97,49 % a las 288 horas. Finalmente, en las pruebas de patogenicidad contra adultos de la broca del café, los aislamientos TOR-M9, TOR-M16 y MNR-M1 lograron una mortalidad del 100 %. Estos resultados evidencian el alto potencial entomopatógeno de los aislados nativos de *Metarhizium sp*., posicionándose como candidatos viables para el desarrollo de bioplaguicidas destinados al control de *H*. *hampei*, ofreciendo una alternativa accesible, económica y ambientalmente sostenible.

1. **Hipótesis**

En las zonas productoras de plátano en Ñunya Jalca, Amazonas, existen especies nativas de *Metarhizium spp*. con potencial de biocontrol sobre el picudo rayado del plátano (*Metamasius hemipterus*), que pueden ser integradas como alternativa de control biológico

1. **Metodología** 
    1. _~~​*  ****Lugar de ejecución o ámbito**​**​*​~~_

El presente estudio involucrará actividades en campo y en laboratorio. Los aislados nativos de *Metarizhium* *spp*. se obtendrán de muestras de adultos micosados de *M*. *hemipterus* mediante un muestreo dirigido, en plantaciones de plátano en el Centro Poblado de Ñunya Jalca, Región de Amazonas.

El Laboratorio de Investigación en Sanidad Vegetal (LABISANV) de la Universidad Nacional Toribio Rodríguez de Mendoza de Amazonas, en el departamento de Amazonas, en coordenadas geográficas de latitud: -6.233678, Longitud: -77.853778 y una altitud de 2353 m.s.n.m.

    1. _~~​*  ****Nivel y tipo de investigación**​**​*​~~_

_~~​*​**Se enmarca en un nivel descriptivo, ya que busca identificar y caracterizar aislados nativos de *Metarhizium spp *. con potencial de biocontrol sobre *M *. *hemipterus *en las parcelas productoras de plátano en Ñunya Jalca, Amazonas.* *​*​*​*​*​**​*​~~_

_~~​*​**Se clasifica como una investigación básica, debido a que su principal objetivo es generar conocimiento sobre la diversidad y distribución de aislados nativos de *Metarhizium spp *. Sin embargo, los resultados obtenidos podrían servir como base para futuras investigaciones que se centren en el desarrollo de estrategias de control biológico del picudo rayado del plátano *M *. *hemipterus * .**​*​*​*​*​**​*​~~_

    1. _~~​* **Población, muestra y muestreo**​*​~~_

  Población: 	La población estará compuesta por el conjunto de parcelas productoras de plátano en Ñunya Jalca, Amazonas. 

  Muestra: 	Será compuesta por adultos micosados de *M*. *hemipterus* característico de *Metarhizium spp*. 

  Muestreo: 	El muestreo será dirigido, debido a que se tomarán solo adultos micosados de *M*. *hemipterus* con presencia característica de *Metarhizium spp*.

    1. _~~​*  ****Variables de estudio**​**​*​~~_
        1. _~~​*​**Variables independientes**​*​~~_

_~~​*​**Aislados nativos de *Metarizhium* spp * .***​*​~~_

_~~​*​**Temperatura (°C )***​~~_

        1. _~~​*​**Variables dependientes**​*​~~_

Especies encontradas

Crecimiento micelial (CM)

Producción de conidias (PdC)

Germinación de conidias (GdC)



```Unknown element type at this position: UNSUPPORTED```    1.  **Operacionalización de variables**

**Tabla 1:** Tabla de operacionalización de variables


| **Tipo**                                                                                | **Variables de estudio**                                                                | **Concepto**                                                                            | **Dimensiones**                                                                         | **Indicadores**                                                                         | **Unidad de medida**                                                                     |
|-----------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------|
| **Independiente**                                                                       | Aislados nativos de *Metarhizium* spp.                                                  | Aislados fúngicos nativas del género *Metarhizium* obtenidas de plantaciones de plátano | Caracterización morfológica, fisiológica, patogénica y cultural                         | Color, tamaño, forma y textura de colonia, morfología de conidios                       | Cualitativa / Observación directa                                                        |
|                                                                                         | Temperatura (°C)                                                                        | Grado de calor al que son expuestos los aislados durante su crecimiento                 | Condiciones térmicas                                                                    | Rango térmico de incubación: 20, 24, 28 °C                                              | Grados Celsius (°C)                                                                      |
| **Dependiente**                                                                         | Crecimiento micelial (CM)                                                               | Expansión del micelio en medio sólido                                                   | Expansión radial                                                                        | Diámetro de las colonias hasta que al menos una llene placa                             | Milímetros (mm)                                                                          |
|                                                                                         | Producción de conidias (PdC)                                                            | Capacidad del hongo para producir esporas (conidias)                                    | Concentración de esporas                                                                | Número de conidias por unidad de volumen                                                | Conidias/mL                                                                              |
|                                                                                         | Germinación de conidias (GdC)                                                           | Porcentaje de conidias que logran germinan                                              | Viabilidad de conidias                                                                  | Porcentaje de conidias germinadas                                                       | Porcentaje (%)                                                                           |




```Unknown element type at this position: UNSUPPORTED```    1.  **Métodos** 
        1. _~~​*​**Obtención de muestras** *​~~_

Adultos micosados de *M*. *hemipterus* serán obtenidos mediante un muestreo dirigido, en las plantaciones de plátano ubicadas en el Centro Poblado Ñunya Jalca, Amazonas. Los adultos micosados serán colocados dentro de viales estériles y transferidos a Coolers para su transporte al Laboratorio de Investigación en Sanidad Vegetal (LABISANV), según Mayo (2024).

        1. _~~​*​**Obtención de aislados**​*​~~_

De acuerdo a la metodología utilizada por Torres *et al*. (2016)**,** Los adultos con signos de micosis serán desinfectados superficialmente mediante inmersión en una solución de hipoclorito de sodio al 0,5 % durante 5 minutos, seguido de tres lavados con agua destilada estéril (ADE). Posteriormente, se colocarán individualmente en cámaras húmedas y se incubarán a 25 °C durante 8 días con el objetivo de inducir la esporulación. Para la propagación de los aislamientos, se empleará como sustrato el medio de cultivo agar dextrosa de Sabouraud suplementado con 0,1 % de extracto de levadura (ADS+EL).

        1. _~~​*​**Caracterización morfológica**​*​~~_

Para la identificación se describirán las estructuras reproductivas de los aislados, de acuerdo con Humber (2012). Para la caracterización, según Mayo Hernández (2024), después de 14 días de crecimiento de los aislados en cajas de Petri con medio de cultivo Agar-Dextrosa Saboraud + 0.1% de extracto de levadura (ADS+EL), se determinarán las características de la colonia: tamaño, morfología y conidiación. Además, para la descripción microscópica se hará microcultivo, con una suspensión de esporas sobre discos de ADS de 0.5 cm de diámetro, bajo un cubreobjeto para cada aislamiento. Los discos inoculados se incubaron a 25 ºC en una cámara húmeda durante 5 días. Para el montaje de muestras y morfometría, según Oliva et al. (2024), montaje de portaobjetos semipermanentes con azul de lactofenol. Los cubreobjetos con esporas se retirarán cuidadosamente de los microcultivos con pinzas y se transfirieron a portaobjetos previamente preparados. Luego, los montajes se secaran con papel absorbente y se sellaron con esmalte de uñas transparente para su conservación. Se observarán las estructuras microscópicas con un microscopio Leica® (Leica Microsystems, Wetzlar, Alemania) y se obtendrán imágenes para medir la longitud y el ancho de los conidios. Las mediciones de las estructuras microscópicas se realizarán con el software Image Tool 3.0.

        1. _~~​*​**Caracterización fisiológica**​*​~~_
            1. _~~​* **Crecimiento micelial**​*​~~_

A partir de colonias con 8 días de crecimiento, se tomará un fragmento de 5 x 5 mm desde el borde y se transferirá al centro de una caja Petri de 90 mm de diámetro, que contiene medio SDA suplementado con extracto de levadura. Las placas se incubarán en condiciones de oscuridad a temperaturas de 20, 24 y 28 ± 1 °C. El crecimiento micelial (CM) se registrará cada dos días, hasta que el hongo cubra por completo la superficie de la placa, utilizando la medición del último día para el análisis estadístico. Cada combinación de aislamiento y temperatura se evaluará con cinco repeticiones. Para determinar el efecto de la temperatura sobre el crecimiento, se calculará el porcentaje de inhibición o incremento del crecimiento radial al comparar 20 °C con 24 °C, aplicando la fórmula: % inhibición/incremento = [(crecimiento a 24 °C × 100) / crecimiento a 20 °C]-100 (Torres et al., 2013).

            1. _~~​* **Producción conidial**​*​~~_

Se tomarán fragmentos de 5 x 5 mm del borde de colonias de 8 días de edad y se transferirán a cajas Petri que contienen medio ADS complementado con extracto de levadura (E.L.). Estas placas serán incubadas en oscuridad durante 15 días a temperaturas de 20, 24 y 28 ± 1 °C. Finalizado este período, los conidios se recolectarán inundando la superficie del cultivo con agua destilada estéril (ADE) con Tween 80 al 0,1 %, se rasparán cuidadosamente con una espátula de acero inoxidable. La suspensión obtenida se homogeneizará durante un minuto usando un agitador magnético. Para separar los conidios del micelio, se filtrará la mezcla a través de gasa clínica estéril. La producción de conidios (PdC) por cada aislamiento se cuantificará mediante el uso de una cámara de Neubauer. Se establecerán cinco repeticiones por aislamiento. El número de conidios por mililitro se calculará aplicando la fórmula propuesta Lipa & Slizynski (1973):

**C = (Cc) (4 x 106) (Fd/80)**

Donde:

**C** = número de conidios,

**Cc** = número promedio de conidios contados en la cámara de Neubauer 

**Fd** = factor de dilución

El impacto de la temperatura sobre la producción de conidios (PdC) en medio de cultivo ADS se analizará mediante el cálculo del porcentaje de inhibición o incremento, comparando los valores obtenidos a 20 °C y 28 °C respecto a los de 24 °C. Para ello, se emplearán las siguientes fórmulas: % INH/INC = [(PdC a 28 °C × 100) / PdC a 20 °C] - 100, y % INH/INC = [(PdC a 28 °C × 100) / PdC a 20 °C]-100 (Torres de la C. et al., 2013).

            1. _~~​* **Porcentaje de germinación**​*​~~_

A partir de cultivos con 19 días de desarrollo, se preparará una suspensión con una concentración de 5 x 10⁶ conidios por mililitro. De esta, se tomarán 30 µL que serán inoculados en cajas de Petri con medio ADS + EL, las cuales se incubarán a temperaturas de 20, 24 y 28 ± 1 °C. La evaluación de la germinación comenzará a partir de la séptima hora, mediante la observación de 100 conidios por lectura, y se continuará hasta que alguno de los aislamientos alcance un 90 % de germinación (Torres et al., 2016).

        1. _~~​*​**Evaluación de patogenicidad**​*​~~_

Los adultos de *M*. *hemipterus* se recolectarán en las mismas plantaciones donde se efectuó el muestreo inicial. Estos serán sumergidos durante un minuto en una suspensión con una concentración de 1 x 10⁷ conidios por mililitro, complementada con Tween 80 al 0,1 %. Los controles serán tratados de igual forma, pero utilizando solamente agua destilada estéril con Tween 80 al 0,1 %. Posteriormente, los insectos tratados se colocarán en recipientes plásticos, agrupando 10 individuos por unidad experimental, con cinco repeticiones por cada aislamiento. Las condiciones de incubación serán de 25 ± 1 °C. La mortalidad será registrada diariamente y los individuos muertos se transferirán a una cámara húmeda para favorecer la esporulación (Mayo, 2024).

        1. _~~​*​**Producción de conidios en arroz**​*​~~_

Se seguirá la metodología utilizada por Torres et al. (2016), Se emplearán 50 gramos de arroz depositados en bolsas de polipapel, humedecidos con 12 mililitros de agua destilada, y esterilizados a 121 °C durante 20 minutos. Una vez frías, las bolsas serán inoculadas con 5 mililitros de suspensión con 1 x 10⁶ conidios por mililitro, e incubadas durante 15 días a una temperatura constante de 25 ± 1 °C y bajo un fotoperiodo de 12 horas luz y 12 horas oscuridad. Para cada aislamiento se realizarán cinco repeticiones. Al término del periodo de incubación, los 50 gramos de arroz se mezclarán con 150 mililitros de agua destilada estéril más Tween 80 al 0,1 %, agitándose durante 10 minutos. Luego, la mezcla será filtrada con gasa clínica para separar los conidios del sustrato y del micelio. Finalmente, el número de conidios se cuantificará utilizando una cámara de Neubauer, estimando la producción por gramo (PdC g⁻¹) mediante la fórmula de Lipa & Slizynski (1973), descrita anteriormente.

    1. _~~​*  ****Análisis de datos**​**​*​~~_

_~~​* * ****​~~_

    1. _~~​*  ****Cronograma**​**​*​~~_
1. **Referencias bibliográficas**



_~~​*​**Algarate, D. C., & Marianella, O. (2023). Determinación del efecto de Metarhizium anisopliae para el control de adultos de Cryptocephalus sp. En condiciones de laboratorio. https://hdl.handle.net/20.500.14414/17611**​*​~~_

_~~​*​**Aw, K. M. S., & Hue, S. M. (2017). Mode of Infection of Metarhizium spp. Fungus and Their Potential as Biological Control Agents. Journal of Fungi, 3(2), Article 2. https://doi.org/10.3390/jof3020030**​*​~~_

_~~​*​**Baró, Y., Schuster, C., Gato, Y., Márquez, M. E., & Leclerque, A. (2022). Characterization, identification and virulence of Metarhizium species from Cuba to control the sweet potato weevil, Cylas formicarius Fabricius (Coleoptera: Brentidae). Journal of Applied Microbiology, 132(5), 3705-3716. https://doi.org/10.1111/jam.15460**​*​~~_

_~~​*​**Chuquibala-Checan, B., Torres-de la Cruz, M., Leiva, S., Hernandez-Diaz, E., Rubio, K., Goñas, M., Arce-Inga, M., & Oliva-Cruz, M. (2023). In Vitro Biological Activity of Beauveria bassiana, Beauveria peruviensis, and Metarhizium sp. against Hypothenemus hampei (Coleoptera: Curculionidae). International Journal of Agronomy, 2023(1), 4982399. https://doi.org/10.1155/2023/4982399**​*​~~_

_~~​*​**Gerónimo-Torres, J. D. C., Torres-de-la-Cruz, M., Cruz, M. P., De-la-Cruz-Pérez, A., Ortiz-garcía, C. F., & Cappello-García, S. (2016). Caracterización de aislamientos nativos de Beauveria bassiana y su patogenicidad hacia Hypothenemus hampei, en Tabasco, México. Revista Colombiana de Entomología, 42(1), 28-35 .***​~~_

_~~​*​**Humber, R. A. (2012). Chapter VI - Identification of entomopathogenic fungi. En L. A. Lacey (Ed.), Manual of Techniques in Invertebrate Pathology (Second Edition) (pp. 151-187). Academic Press. https://doi.org/10.1016/B978-0-12-386899-2.00006-3**​*​~~_

_~~​*​**Lipa, J. J., & Slizynski, K. (1973). Wskazówki metodyczne i terminologia do wyznaczania średniej dawki śmiertelnej (LD50) w patologii owadów i toksykologii. Prace Naukowe Instytutu Ochrony Roślin, 15(1). http://agro.icm.edu.pl/agro/element/bwmeta1.element.agro-a6c704fd-061e-4c7e-bbcd-add4213ad0fe**​*​~~_

_~~​*​**Mayo Hernández, M. Á. (2024). Caracterización de aislamientos nativos de Metarhizium sp. para el control biológico de la chinche Antiteuchus Tripterus (Hemiptera: Pentatomidae) en Tabasco, México. https://ri.ujat.mx/handle/200.500.12107/4470**​*​~~_

_~~​*​**Oliva-Cruz, M., Altamirano-Tantalean, M. A., Chuquizuta-Torres, R., Oliva-Cruz, C., Maicelo-Quintana, J. L., Leiva-Espinoza, S. T., Culqui, L., Mendez-Fasabi, L. D., Rojas Ventura, H. M., Corazon-Guivin, M. A., & Juarez-Contreras, L. (2024). Isolation and Characterization of Native Isolates of Metarhizium sp. As a Biocontrol Agent of Hypothenemus hampei in Rodríguez de Mendoza Province—Peru. Agronomy, 14(7), Article 7. https://doi.org/10.3390/agronomy14071341**​*​~~_

_~~​*​**Torres de la C., M., Cortez M., H., Ortiz G., C. F., Cappello G., S., & de la Cruz P., A. (2013). Caracterización de aislamientos nativos de Metarhizium anisopliaey su patogenicidad hacia Aeneolamia postica, en Tabasco, México. Revista Colombiana de Entomología, 39(1), 40-46 .***​~~_

_~~​*​**Valle, S., Carrera, K., Alemán, R., Caicedo, W., Valle, S., Carrera, K., Alemán, R., & Caicedo, W. (2021). Caracterización de aislamientos nativos de Metarhizium spp. Para el control de Mahanarva andigena en el cultivar de caña de azúcar POJ93 en la Amazonia ecuatoriana. Idesia (Arica), 39(1), 69-75. https://doi.org/10.4067/S0718-34292021000100069**​*​~~_



